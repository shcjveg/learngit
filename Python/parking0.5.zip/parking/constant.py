#!/usr/bin/env python
# -*- coding: utf-8 -*-


class Constant(object):
    def __init__(self):
        self.MAX = 30
        self.MIN_IN_TIME = 1
        self.MAX_IN_TIME = 5
        self.MIN_OUT_TIME = 2
        self.MAX_OUT_TIME = 6
        self.NODE_ID = 2
        # self.IP = '127.0.0.1'
        # self.PORT = 8899

